If you have a feature request, please see the Contribution Guidelines before
proceeding.

If you have a bug report, please supply the following information:

- Operating System (eg. Windows, Linux, Mac)
- Terminal Emulator (eg. xterm, gnome-terminal, konsole, ConEmu, Terminal.app, Command Prompt)
- Bug behaviour
- Expected behaviour
- Complete sample that reproduces the bug
