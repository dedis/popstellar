package shapes
	
type Square struct{
	l int	
}
func InitSquare(l1 int) (Square){
	return Square{l1}
}
func (s Square) Area() int{
	return s.l*s.l
}
