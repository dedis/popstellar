// <<<<< toggle,8,3,8,10,pass
package main

import "fmt"
import "reflect"

func main() {
  i:=3+4.5
  fmt.Println("type of i is", reflect.TypeOf(i))
  fmt.Println("value of i is", i)
}
