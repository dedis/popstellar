package main

func main() {
  fmt.Println("Hello, Go") // <<<<< null,1,1,1,1,true,pass
}
