// <<<<< toggle,10,2,10,9,pass
package main

import "fmt"

func f() int {
	return 1
}
func main() {
	i := f()
	fmt.Println("Value of i :",i)
}
