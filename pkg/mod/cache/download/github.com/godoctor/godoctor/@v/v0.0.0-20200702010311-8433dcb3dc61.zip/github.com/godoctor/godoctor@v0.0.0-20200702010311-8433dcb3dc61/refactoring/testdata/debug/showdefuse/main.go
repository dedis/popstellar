package main

import "fmt"

func main() {
	type Fraction struct {
		Numerator, Denominator int
	}

	one, two := 1, 9999
	two = 2
	frac := Fraction{one, two}
	frac.Denominator = 4
	if two = 222; 1 < 5 {
		frac.Numerator = 3
	}
	fmt.Println(frac)
}

//<<<<<debug,1,1,1,1,showdefuse,fail
//<<<<<debug,5,1,5,1,showdefuse,pass
