package main //<<<<<debug,1,1,1,1,showpackages,pass

import "pkg"

func main() {
	pkg.F()
}
