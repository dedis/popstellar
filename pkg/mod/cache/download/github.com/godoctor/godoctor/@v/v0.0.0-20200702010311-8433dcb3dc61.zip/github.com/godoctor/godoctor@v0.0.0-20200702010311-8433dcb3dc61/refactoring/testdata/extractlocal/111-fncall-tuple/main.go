package main

import "fmt"

func main() {
	fmt.Printf("Test\n") // <<<<< var,6,2,6,21,variable,fail
}
