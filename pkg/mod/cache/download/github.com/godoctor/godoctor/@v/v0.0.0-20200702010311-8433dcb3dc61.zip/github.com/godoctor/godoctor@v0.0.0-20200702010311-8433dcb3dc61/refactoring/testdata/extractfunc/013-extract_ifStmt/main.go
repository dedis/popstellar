// <<<<< extract,9,2,11,2,foo,pass

package main

import "fmt"

func main() {
	i := 2 + 0
	if i%2 == 0 {
		fmt.Println("i is even")
	}
	fmt.Println("end of main function")
}
