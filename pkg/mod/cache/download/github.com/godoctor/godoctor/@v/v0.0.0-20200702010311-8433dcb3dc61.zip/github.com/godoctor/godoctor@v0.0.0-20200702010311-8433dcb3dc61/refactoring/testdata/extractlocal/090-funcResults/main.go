package main

import "fmt"

func apple(val int) string {// <<<<< var,5,21,5,26,newVar,fail
		a := "apple +"
		return a
}

func main() {
	inum := 5
	s := apple(inum)

	fmt.Println(s)
}
