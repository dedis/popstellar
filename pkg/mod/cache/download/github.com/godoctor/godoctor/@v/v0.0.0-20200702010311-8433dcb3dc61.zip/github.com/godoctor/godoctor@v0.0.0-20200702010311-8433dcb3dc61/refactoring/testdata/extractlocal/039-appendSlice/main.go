package main

import (
	"fmt"
	"strconv"
)

func main() {
	x := 5
	i, err := x, false
	var tags []string
	alpha := make([]string, 1)
	alpha = append(alpha, "8")
	if err == true {
		fmt.Println(err)
	}
	fmt.Println("divisible by 5:" + strconv.Itoa(i))
	tag := ""
	if tag == "" {
		tag = "yes"
	}
	if len(tag) != 0 {
		tags = append(tags, tag) // <<<<< var,23,3,23,6,newVar,fail
	}
}
