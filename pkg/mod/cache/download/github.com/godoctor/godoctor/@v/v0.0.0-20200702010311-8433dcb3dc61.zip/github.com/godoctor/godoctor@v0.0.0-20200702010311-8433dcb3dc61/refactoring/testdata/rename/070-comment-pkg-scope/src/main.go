package main

import (
	"a"
	"b"
	"fmt"
)

func main() {
	// m
	fmt.Printf("%v %v\n", a.M(), b.M())
}
