package b

type I interface {
	m()
}

type T int

func (T) m() {
}
