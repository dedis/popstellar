// <<<<< toggle,10,2,10,16,pass
package main

import "fmt"

func f() int {
	return 1
}
func main() {
	var i int = f()
	fmt.Println("Value of i :",i)
}
