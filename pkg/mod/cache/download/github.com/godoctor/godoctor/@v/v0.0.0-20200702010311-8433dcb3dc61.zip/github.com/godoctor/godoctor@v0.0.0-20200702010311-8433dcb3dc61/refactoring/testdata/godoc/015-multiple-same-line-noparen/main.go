package main // <<<<< godoc,1,1,1,1,pass

var a, B, c, D int

// Known limitation - no comment added

func main() {
}
