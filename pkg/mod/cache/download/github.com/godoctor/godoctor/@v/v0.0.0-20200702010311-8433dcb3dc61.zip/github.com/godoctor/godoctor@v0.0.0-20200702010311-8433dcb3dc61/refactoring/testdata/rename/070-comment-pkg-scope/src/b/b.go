package b

import "a"

// m
func M() {
}

// m
func m() {
	a.M()
}
