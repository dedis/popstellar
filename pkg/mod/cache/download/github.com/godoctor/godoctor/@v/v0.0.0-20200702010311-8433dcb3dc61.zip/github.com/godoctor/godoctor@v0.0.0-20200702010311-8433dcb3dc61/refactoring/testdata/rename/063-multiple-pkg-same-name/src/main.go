package main

import (
	"a"
	"b"
	"fmt"
)

func main() {
	var i1 a.T = 3
	var i2 b.T = 4
	fmt.Printf("%v %v\n", i1, i2)
}
