package main

import "fmt"

func main() {
	x := []int{1 + 2, 4, 5} //<<<<< var,6,13,6,17,newVar,pass
	fmt.Println(x)
}
