package secondpackage 

import (
"fmt"
"mypackage"
)

func SecondFunction() {             
	
mystructvar := mypackage.Mystruct {"Hiii" }  

fmt.Println("value is",mystructvar.Mymethod())	

}
