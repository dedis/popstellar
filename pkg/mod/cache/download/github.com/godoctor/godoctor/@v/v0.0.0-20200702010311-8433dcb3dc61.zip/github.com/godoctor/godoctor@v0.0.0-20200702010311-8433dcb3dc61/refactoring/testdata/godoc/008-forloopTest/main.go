package main // <<<<< godoc,1,1,1,1,pass

import "fmt"

func main() {
	j := 0
	for i := 0; i < 5; i++ {
		j++
	}
	fmt.Println("hello world!")
}
