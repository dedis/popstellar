// <<<<< toggle,7,2,7,19,pass
package main

import "fmt"

func main() {
	ch:=make(chan int)
	fmt.Println("Channel ch :",ch)
}
