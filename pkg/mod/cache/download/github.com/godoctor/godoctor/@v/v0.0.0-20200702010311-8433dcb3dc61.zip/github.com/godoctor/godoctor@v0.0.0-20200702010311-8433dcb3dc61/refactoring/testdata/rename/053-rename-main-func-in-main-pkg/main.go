package main

func main() { //<<<<<rename,3,6,3,6,foo,fail
}
