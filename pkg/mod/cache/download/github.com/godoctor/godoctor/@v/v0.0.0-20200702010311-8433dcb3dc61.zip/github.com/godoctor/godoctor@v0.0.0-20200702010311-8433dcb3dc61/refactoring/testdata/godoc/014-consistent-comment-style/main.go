package main // <<<<< godoc,1,1,1,1,pass

type (
	// A is a type
	A int
	B int
	c string
)

const (
	StatusOk = 1
	// StatusBad is bad
	StatusBad = 2
)

var (
	Foo = "Foo"
	Bar = "Bar"
)

func main() {
}
