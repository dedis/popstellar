package main

import "fmt"
import "mypackage"

func main() {
	fmt.Println(mypackage.MyFunction(5))
}
