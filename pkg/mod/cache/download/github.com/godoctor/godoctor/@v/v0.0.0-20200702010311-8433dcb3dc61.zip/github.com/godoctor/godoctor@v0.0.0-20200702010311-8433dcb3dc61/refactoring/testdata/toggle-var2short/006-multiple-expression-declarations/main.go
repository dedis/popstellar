// <<<<< toggle,7,1,7,19,pass
package main

import "fmt"

func main() {
var i,j = 3.5+6,7+1
fmt.Println("The value of variables i,j are :",i,j)
}
